function Number(item){
return /[0-9]+/.test(item);
}
export default Number;